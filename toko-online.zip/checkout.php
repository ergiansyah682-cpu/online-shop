<?php
session_start();
include 'config.php';
$user = $_SESSION['user'];

if (isset($_POST['checkout'])) {
    $alamat = $_POST['alamat'];

    $data = mysqli_query($conn, "SELECT SUM(products.harga * cart.qty) as total FROM cart JOIN products ON cart.produk_id = products.id WHERE user='$user'");
    $d = mysqli_fetch_assoc($data);
    $total = $d['total'];

    mysqli_query($conn, "INSERT INTO orders (user,total,alamat) VALUES ('$user','$total','$alamat')");
    mysqli_query($conn, "DELETE FROM cart WHERE user='$user'");

    header("Location: riwayat.php");
}
?>

<form method="POST">
<textarea name="alamat" placeholder="Alamat"></textarea><br>
<button name="checkout">Checkout</button>
</form>
