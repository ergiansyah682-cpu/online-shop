<?php
session_start();
include 'config.php';
$user = $_SESSION['user'];
?>

<h2>Riwayat</h2>
<table border="1">
<tr><th>ID</th><th>Total</th><th>Alamat</th></tr>

<?php
$data = mysqli_query($conn, "SELECT * FROM orders WHERE user='$user'");
while ($d = mysqli_fetch_assoc($data)) {
?>

<tr>
<td><?= $d['id'] ?></td>
<td><?= $d['total'] ?></td>
<td><?= $d['alamat'] ?></td>
</tr>

<?php } ?>
</table>
