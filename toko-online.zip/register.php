<?php
include 'config.php';

if (isset($_POST['register'])) {
    $user = $_POST['username'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn, "INSERT INTO users (username, password) VALUES ('$user','$pass')");
    header("Location: login.php");
}
?>
<form method="POST">
<h2>Register</h2>
<input type="text" name="username"><br>
<input type="password" name="password"><br>
<button name="register">Daftar</button>
</form>
