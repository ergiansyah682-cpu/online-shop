<?php
session_start();
include 'config.php';

if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $data = mysqli_query($conn, "SELECT * FROM users WHERE username='$user'");
    $d = mysqli_fetch_assoc($data);

    if ($d && password_verify($pass, $d['password'])) {
        $_SESSION['user'] = $d['username'];
        header("Location: dashboard.php");
    } else {
        echo "Login gagal!";
    }
}
?>
<form method="POST">
<h2>Login</h2>
<input type="text" name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<button name="login">Login</button>
</form>
<a href="register.php">Register</a>
