CREATE DATABASE toko_online;
USE toko_online;

CREATE TABLE users (
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50),
password VARCHAR(255)
);

CREATE TABLE products (
id INT AUTO_INCREMENT PRIMARY KEY,
nama_produk VARCHAR(100),
harga INT,
gambar VARCHAR(255)
);

INSERT INTO products (nama_produk, harga, gambar) VALUES
('Sepatu', 200000, 'https://via.placeholder.com/150'),
('Kaos', 50000, 'https://via.placeholder.com/150');

CREATE TABLE cart (
id INT AUTO_INCREMENT PRIMARY KEY,
user VARCHAR(50),
produk_id INT,
qty INT
);

CREATE TABLE orders (
id INT AUTO_INCREMENT PRIMARY KEY,
user VARCHAR(50),
total INT,
alamat TEXT
);
