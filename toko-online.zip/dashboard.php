<?php
session_start();
include 'config.php';
if (!isset($_SESSION['user'])) header("Location: login.php");
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-4">
<h2>Produk</h2>
<a href="cart.php" class="btn btn-warning">Keranjang</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
<div class="row mt-3">

<?php
$data = mysqli_query($conn, "SELECT * FROM products");
while ($p = mysqli_fetch_assoc($data)) {
?>
<div class="col-md-4">
<div class="card">
<img src="<?= $p['gambar'] ?>" class="card-img-top">
<div class="card-body">
<h5><?= $p['nama_produk'] ?></h5>
<p>Rp <?= $p['harga'] ?></p>
<form method="POST">
<input type="hidden" name="id" value="<?= $p['id'] ?>">
<button name="add" class="btn btn-primary">Tambah</button>
</form>
</div>
</div>
</div>
<?php } ?>

</div>
</div>

<?php
if (isset($_POST['add'])) {
    $id = $_POST['id'];
    $user = $_SESSION['user'];
    mysqli_query($conn, "INSERT INTO cart (user, produk_id, qty) VALUES ('$user','$id',1)");
}
?>
