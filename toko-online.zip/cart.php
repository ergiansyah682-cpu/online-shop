<?php
session_start();
include 'config.php';
$user = $_SESSION['user'];

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM cart WHERE id='$id'");
}

if (isset($_POST['update'])) {
    foreach ($_POST['qty'] as $id => $qty) {
        mysqli_query($conn, "UPDATE cart SET qty='$qty' WHERE id='$id'");
    }
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-4">
<h2>Keranjang</h2>

<form method="POST">
<table class="table">
<tr><th>Produk</th><th>Harga</th><th>Qty</th><th>Total</th><th>Aksi</th></tr>

<?php
$total = 0;
$data = mysqli_query($conn, "SELECT cart.*, products.nama_produk, products.harga FROM cart JOIN products ON cart.produk_id = products.id WHERE user='$user'");

while ($d = mysqli_fetch_assoc($data)) {
$subtotal = $d['harga'] * $d['qty'];
$total += $subtotal;
?>

<tr>
<td><?= $d['nama_produk'] ?></td>
<td><?= $d['harga'] ?></td>
<td><input type="number" name="qty[<?= $d['id'] ?>]" value="<?= $d['qty'] ?>"></td>
<td><?= $subtotal ?></td>
<td><a href="?hapus=<?= $d['id'] ?>" class="btn btn-danger">Hapus</a></td>
</tr>

<?php } ?>

</table>

<button name="update" class="btn btn-primary">Update</button>
</form>

<h4>Total: <?= $total ?></h4>
<a href="checkout.php" class="btn btn-success">Checkout</a>
</div>
